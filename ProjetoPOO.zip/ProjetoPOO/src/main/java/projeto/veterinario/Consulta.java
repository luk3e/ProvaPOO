package projeto.veterinario;

import java.util.Objects;

public class Consulta {

    private Integer id;
    private String dataConsulta;
    private String descricaoExame;
    private String historico;



    public Consulta() {
    }

    public Consulta(Integer id, String dataconsulta, String descricao, String historico) {
        this.id = id;
        this.dataConsulta = dataconsulta;
        this.descricaoExame = descricao;
        this.historico = historico;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDataconsulta() {
        return dataConsulta;
    }

    public void setDataconsulta(String dataconsulta) {
        this.dataConsulta = dataconsulta;
    }

    public String getDescricao() {
        return descricaoExame;
    }

    public void setDescricao(String descricao) {
        this.descricaoExame = descricao;
    }

    public String getHistorico() {
        return historico;
    }

    public void setHistorico(String historico) {
        this.historico = historico;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Consulta consulta = (Consulta) o;
        return Objects.equals(id, consulta.id) && Objects.equals(dataConsulta, consulta.dataConsulta) && Objects.equals(descricaoExame, consulta.descricaoExame) && Objects.equals(historico, consulta.historico);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, dataConsulta, descricaoExame, historico);
    }

    @Override
    public String toString() {
        return "Consulta{" +
                "id=" + id +
                ", dataconsulta='" + dataConsulta + '\'' +
                ", descricao='" + descricaoExame + '\'' +
                ", historico='" + historico + '\'' +
                '}';
    }
}
